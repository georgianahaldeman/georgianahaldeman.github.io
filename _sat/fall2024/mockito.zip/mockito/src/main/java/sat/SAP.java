package sat;

public interface SAP {
    void send(Invoice invoice);
}
