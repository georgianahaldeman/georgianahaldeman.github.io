package sat.advanced;

public class SAPException extends RuntimeException {
}
