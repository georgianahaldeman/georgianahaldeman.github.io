package sat.advanced;

public interface SAP {
    void send(SapInvoice invoice);
}
